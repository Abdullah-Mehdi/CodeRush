package com.example.CodeRush;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeRushApplicationTests {

	@Test
	void contextLoads() {
	}

}
