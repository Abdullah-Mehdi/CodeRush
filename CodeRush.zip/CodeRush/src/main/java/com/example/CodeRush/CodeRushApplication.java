package com.example.CodeRush;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeRushApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeRushApplication.class, args);
	}

}
